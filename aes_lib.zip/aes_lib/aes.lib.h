#ifndef AES_LIB_H
#define AES_LIB_H

#include <bits/stdc++.h>
#include "aes.cipherblock.lib.h"
#include "modes/aes.modes.h"

using namespace std;

#endif //AES_LIB_H
